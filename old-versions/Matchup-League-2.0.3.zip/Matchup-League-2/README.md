# Matchup-League-2

## New for 2.0.3
- Save and load careers
- Fighter rankings rework

## Planned for 2.0.4
- Saveable settings

## Planned for 2.1
- Postseason tournament